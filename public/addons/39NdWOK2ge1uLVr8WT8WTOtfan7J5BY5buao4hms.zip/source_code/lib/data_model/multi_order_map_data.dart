import 'package:active_flutter_delivery_app/data_model/order_mini_response.dart';

class CustomLatLng{
 final Order? order;
  CustomLatLng({this.order});
}