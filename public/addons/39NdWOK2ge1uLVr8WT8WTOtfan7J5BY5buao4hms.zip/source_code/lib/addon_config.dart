import 'package:flutter/material.dart';

class AddonConfig{
  static bool otp_addon_installed = true;

}