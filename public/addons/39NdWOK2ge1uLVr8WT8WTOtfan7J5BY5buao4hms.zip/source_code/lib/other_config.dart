
class OtherConfig{
  static const bool USE_GOOGLE_MAP = true;
}