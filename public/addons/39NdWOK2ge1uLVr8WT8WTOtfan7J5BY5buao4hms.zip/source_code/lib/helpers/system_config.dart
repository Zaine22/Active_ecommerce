import 'package:active_flutter_delivery_app/data_model/login_response.dart';

class SystemConfig {
  static User? systemUser;

}