package com.example.active_flutter_delivery_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
